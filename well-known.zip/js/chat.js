
// $("body").append('<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=2e707045-5edc-45cd-8a9c-8522bee4dfff"> </script>');

// function setButtonURL(){
//     $zopim.livechat.window.show();
// }

// function setButtonURL() {
//     zE.activate();
// }
// $('.chat').click( function(){
//     zE.activate();
// }); 