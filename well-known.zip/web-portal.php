<?php 
include 'header.php';
?>
<section class="breadcrumb-areav2 ban-main5" >
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-12">
				<div class="bread-titlev2">
					<!-- <h1 class="wow fadeInUp" data-wow-delay=".2s">Upgrade Your Business With Professional Web Portal Development in the USA</h1> -->
					<h1 class="wow fadeInUp" data-wow-delay=".2s">Empower Your Businesses and Streamline the Operations with Custom Web Portal Development </h1>
					<!-- <p class="mt20 wow fadeInUp white" data-wow-delay=".4s">Deliver high-quality, scalable portal anytime anywhere that ensures seamless business processes.</p> -->
					<p class="mt20 wow fadeInUp white" data-wow-delay=".4s">Deliver high-quality, scalable web portal anytime anywhere that ensures seamless online business operations</p>
					<a href="javascript:;" class="btn-main bg-btn lnk wow fadeIn popup_open" onclick="order_now_value(this)" name="for $244" data-wow-delay="0.8s">Get Started <i class="fas fa-chevron-right fa-ani"></i><span class="circle"></span></a>
					<a href="javascript:;" class="btn-main bg-btn2 lnk  wow fadeIn" onclick="setButtonURL();"  data-wow-delay="0.8s">Live Chat<i class="fas fa-chevron-right fa-icon fa-ani"></i><span class="circle"></span></a>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="statistics-wrap bg-gradient5">
	<div class="container">
		<div class="row small t-ctr mt0">
			<div class="col-lg-3 col-sm-6">
				<div class="statistics">
					<div class="statistics-img">
						<img src="images/icons/deal.svg" alt="happy" class="img-fluid">
					</div>
					<div class="statnumb">
						<span class="counter">450</span>
						<p>Happy Clients</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="statistics">
					<div class="statistics-img">
						<img src="images/icons/computers.svg" alt="project" class="img-fluid">
					</div>
					<div class="statnumb counter-number">
						<span class="counter">48</span><span>k</span>
						<p>Projects Done</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="statistics">
					<div class="statistics-img">
						<img src="images/icons/worker.svg" alt="work" class="img-fluid">
					</div>
					<div class="statnumb">
						<span class="counter">95</span><span>k</span>
						<p>Hours Worked</p>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-sm-6">
				<div class="statistics mb0">
					<div class="statistics-img">
						<img src="images/icons/customer-service.svg" alt="support" class="img-fluid">
					</div>
					<div class="statnumb">
						<span class="counter">24</span><span>/</span><span class="counter">7</span>
						<p>Support Available</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<section class="service pad-tb">
	<div class="container">
		<div class="row">
			<div class="col-lg-4">
				<div class="image-block upset bg-shape wow fadeIn">
					<img src="images/about/square-image-5.jpg" alt="image" class="img-fluid" />
				</div>
			</div>
			<div class="col-lg-8 block-1">
				<div class="common-heading text-l pl25">
					<span>Web Portal Development Company in USA</span>
					<h2>Web Portal </h2>
					<p>Websodesign web solution is a professional web portal development service that helps streamline business processes and enhance productivity. Our team excels in custom web portal development and understand that transparency in workflow and ease of use are important. Following this principle, our web portal development company professionals apply all their techniques and design mobile-friendly web portals that assist clients with their business process, build their strong online presence, and take customer interaction to the next level. </p>
				</div>
			</div>
		</div>
	</div>
</section>
<div class="techonology-used-">
	<div class="container">
		<ul class="h-scroll tech-icons">
			<li><a href="#"><img src="images/icons/stack-icon1.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon2.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon3.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon4.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon5.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon6.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon7.png" alt="icon"></a></li>
			<li><a href="#"><img src="images/icons/stack-icon8.png" alt="icon"></a></li>
		</ul>
	</div>
</div>

<section class="service-block bg-gradient6 pad-tb">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="common-heading ptag">
					<!-- <span>SERVICES</span> -->
					<span>Web</span>
					<!-- <h2>Types of Web Portals We Create</h2> -->
					<h2>Portal Design Service Promoting User Engagement</h2>
					<!-- <p class="mb30">We offer a vast variety of web portals to ensure you we provide to make sure that you get an improved version of your business.</p> -->
					<p class="mb30">Websodesign Web Solution is a web portal development agency engendering performance, quality & responsiveness among other features for smooth flow of information & improved connectivity.</p>
				</div>
			</div>
		</div>
		<div class="row upset link-hover">
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".2s">
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-1.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>B2C Portal </h4> -->
					<h4>B2C Web Portal</h4>
					<!-- <p>we make sure our web portal development service team creates a high-quality B2C portal. Make it easy for you to your customer with unique service. Our B2C web portal will be your best option if you want long term relationship with your client. </p> -->
					<p>Websodesign Web Solution ensures web portal development aim to provoke interest in consumers, & build associations. Our web portals offer functionality, content sharing capabilities & multimedia support in one place.</p>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".4s">
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-2.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>B2B Portal </h4> -->
					<h4>Community Web Portal</h4>
					<!-- <p>this web portal is self-service customer service. It allows you to boost sales, reduce costs. Our B2B web portal development service will operate as admin of a customer center.</p> -->
					<p>Websodesign Web Solution extends Web Portal Design Service of Community Web Portal formed to trigger the attention of users with similar interests, foster connectivity, and manage an online community through useful means.</p>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".6s">
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-3.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>Partner Portal </h4> -->
					<h4>Education Web Portal</h4>
					<!-- <p>a perfect portal for staff along with the vendor. We highly recommend getting a web portal development service and make your business process easy. </p> -->
					<p>Websodesign Web Solution comprises a team of website portal designers structuring education web portals ideal for dissemination & promotion of information coming off as the best choice for educational platforms.</p>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay=".8s">
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-4.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>Vendor Portal</h4> -->
					<h4>Vendor Web Portal</h4>
					<!-- <p>a vendor web portal is a one-stop solution. You can easily exchange information and data in no time. Maximize the load of vendor management. </p> -->
					<p>Websodesign Web Solution is leading as a web portal development company with a vendor web portal incorporating a unique feature that aids businesses to collaborate, easily track & execute actions in a simplified manner.</p>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay="1s">
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-5.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>Community Portal</h4> -->
					<h4>B2B Web Portal</h4>
					<!-- <p>our web portal development service includes a community portal that provides you a great user interface. </p> -->
					<p>Our Web Portal Design Service embraces the latest e-commerce practices assisting organizations in advanced correspondence through unique features and functionalities & enabling the possibility of B2B trade activities.</p>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeInUp" data-wow-delay="1.2s">	
				<div class="s-block s_block_ser s_block_ser_portal s_block_ser_web2portal">
					<div class="s-card-icon"><img src="images/icons/web-logo-6.png" alt="service" class="img-fluid" /></div>
					<!-- <h4>Learning Portal</h4> -->
					<h4>Health Web Portal</h4>
					<!-- <p>we make sure that you get the best learning experience through learning web portal development.</p> -->
					<p>Websodesign Web Solution delivers proven web portal design service of health web portals covering information accessibility, consultation, scheduling for improved communication between patients & various healthcare stakeholders.</p>
				</div>
			</div>
		</div>
		<div class="-cta-btn mt70">
			<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.3s">
				<p>Have Access to <span>Experienced Web Portal Developers</span></p>
				<a href="javascript:;" class="btn-main bg-btn2 lnk" onclick="setButtonURL();">Live Chat<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a>
			</div>
		</div>
	</div>
</section>
<section class="portfolio-section featured-project pad-tb">
   <div class="container">
      <div class="row justify-content-center ">
         <div class="col-lg-8">
            <div class="common-heading">
               <span>Our Portfolio</span>
               <h2 class="mb0">View Our Quality Work</h2>
            </div>
         </div>
      </div>
      <div class="row">
         <!--                 <div class="col-lg-8 col-sm-8 mt60 wow fadeInUp" data-wow-delay="0.2s">
            <div class="isotope_item hover-scale">
               <div class="item-image" data-tilt data-tilt-max="2" data-tilt-speed="1000">
                  <a href="javascript:;" > <img src="images/portfolio/image-d.jpg" alt="image" class="img-fluid" /> </a>
               </div>
               <div class="item-info">
                  <h4><a href="#">Ecommerce Development</a></h4>
                  <p>Web Application</p>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-sm-4 mt60 wow fadeInUp" data-wow-delay="0.4s">
            <div class="isotope_item hover-scale">
               <div class="item-image" data-tilt data-tilt-max="2" data-tilt-speed="1000">
                  <a href="javascript:;" > <img src="images/portfolio/image-1.jpg" alt="image" class="img-fluid" /> </a>
               </div>
               <div class="item-info">
                  <h4><a href="#">Creative App</a></h4>
                  <p>iOs, Android</p>
               </div>
            </div>
         </div>
         <div class="col-lg-4 col-sm-4 mt60 wow fadeInUp" data-wow-delay="0.6s">
            <div class="isotope_item hover-scale">
               <div class="item-image" data-tilt data-tilt-max="2" data-tilt-speed="1000">
                  <a href="javascript:;" > <img src="images/portfolio/image-6.jpg" alt="image" class="img-fluid" /> </a>
               </div>
               <div class="item-info">
                  <h4><a href="#">Brochure Design</a></h4>
                  <p>Graphic, Print</p>
               </div>
            </div>
         </div>
         <div class="col-lg-8 col-sm-8 mt60 wow fadeInUp" data-wow-delay="0.8s">
            <div class="isotope_item hover-scale">
               <div class="item-image" data-tilt data-tilt-max="2" data-tilt-speed="1000">
                  <a href="javascript:;" > <img src="images/portfolio/image-c.jpg" alt="image" class="img-fluid" /> </a>
               </div>
               <div class="item-info">
                  <h4><a href="#">Icon Pack</a></h4>
                  <p>iOs, Android</p>
               </div>
            </div>
         </div> -->
       <!--  <div class="col-sm-12">
            <div class="port-tab port_tab_mrg">
               <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                  <a class="nav-item nav-link active" id="nav-contact-tab" data-toggle="tab" href="#portftab3" role="tab" aria-controls="nav-contact" aria-selected="false">Website</a>
                  <a class="nav-item nav-link " id="nav-home-tab" data-toggle="tab" href="#portftab1" role="tab" aria-controls="nav-home" aria-selected="true">Digital Marketing</a>
                  <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#portftab2" role="tab" aria-controls="nav-profile" aria-selected="false">Logo</a>
                  
               </div>
            </div>
         </div> -->
         <div class="col-sm-12">
            
             <!--   <div role="tabpanel" class="tab-pane fade " id="portftab1">
                  <div class="row">
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/1.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/2.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/3.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/4.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/5.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/6.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/7.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/8.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                     <div class="col-sm-4 port-col-6-st">
                        <div class="port-img-small box18 isotope_item hover-scale">
                           <div class="item-image">
                              <a href="images/portfolio/dm/9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                 <img loading="lazy" src="images/portfolio/dm/9.jpg">
                                 <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                              </a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
               <!-- <div role="tabpanel" class="tab-pane fade" id="portftab2">
                  <div class="col-sm-12">
                     <div class="port-tab port-tb-3">
                        
                        <div class="nav nav-tabs nav-fill nav_port" id="nav-tab2" role="tablist">
                           <a class="nav-item nav-link active" data-toggle="tab" href="#portIltab1" role="tab"  aria-selected="true">2D Animation</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portIltab2" role="tab"  aria-selected="false">3D Animation</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portIltab3" role="tab"  aria-selected="false">Iconic</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portIltab4" role="tab"  aria-selected="false">Illustrative</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portIltab5" role="tab"  aria-selected="false">Symbolic</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portIltab6" role="tab"  aria-selected="false">typographic</a>
                        </div>
                     </div>
                     <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade show active" id="portIltab1">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/1.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/1.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/2.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/2.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/3.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/3.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/4.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/4.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/5.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/5.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/6.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/6.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/7.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/7.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/8.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/8.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/2d/9.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/2d/9.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade " id="portIltab2">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/1.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/1.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/2.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/2.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/3.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/3.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/4.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/4.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/5.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/5.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/6.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/6.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/7.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/7.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/8.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/8.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/3d/9.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/logo/3d/9.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portIltab3">
                           <div class="row">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/1.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/2.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/3.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/4.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/5.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/6.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/7.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/8.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/ico/9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/ico/9.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portIltab4">
                           <div class="row">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/1.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/2.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/3.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/4.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/5.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/6.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/7.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/8.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/illus/9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/illus/9.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portIltab5">
                           <div class="row">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/1.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/2.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/3.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/4.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/5.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/6.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/7.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/8.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/sym/9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/sym/9.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portIltab6">
                           <div class="row">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/1.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/2.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/3.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/4.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/5.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/6.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/7.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/8.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/logo/typ/9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/logo/typ/9.jpg">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div> -->
               <div role="tabpanel" class="tab-pane fade show active" id="portftab3">
                  <div class="col-sm-12">
                     <div class="port-tab port-tb-3">
                        <div class="nav nav-tabs nav-fill" id="nav-tab3" role="tablist">
                           <a class="nav-item nav-link active" data-toggle="tab" href="#portwebtab1" role="tab"  aria-selected="true">Business</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portwebtab2" role="tab"  aria-selected="false">Ecommerce</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portwebtab3" role="tab"  aria-selected="false">Parallax</a>
                           <a class="nav-item nav-link" data-toggle="tab" href="#portwebtab4" role="tab"  aria-selected="false">Web Portal</a>
                        </div>
                     </div>
                     <div class="tab-content">
                        <div role="tabpanel" class="tab-pane fade active show" id="portwebtab1">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/1/1-1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/1/1.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/2/2-2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/2/Untitled-1.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/3/3-3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/3/3.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/4/4-4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/4/4.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/5/5-5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/5/5.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/6/6-6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/6/6.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/7/7-7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/7/7.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/8/8-8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/8/8.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/bus/9/9-9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/bus/9/9.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portwebtab2">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/1/1-1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/1/1.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/2/2-2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/2/2.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/3/3-3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/3/3.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/4/4-4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/4/4.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/5/5-5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/5/5.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/6/6-6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/6/6.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/7/7-7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/7/7.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/8/8-8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/8/8.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/ecom/9/9-9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/ecom/9/9.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portwebtab3">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/1.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/1.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/2.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/2.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/3.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/3.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/4.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/4.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/5.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/5.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/6.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/6.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/7.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/7.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/8.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/8.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/parallax/9.mp4" type="video/mp4" class="fancybox fancybox.iframe" rel="ligthbox" tabindex="0">
                                          <video loop="true" autoplay="autoplay" id="vid" muted="">
                                             <source src="images/portfolio/website/parallax/9.mp4" type="video/mp4">
                                          </video>
                                       </div>
                                       <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                    </a>
                                    
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div role="tabpanel" class="tab-pane fade" id="portwebtab4">
                           <div class="row p0">
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/1/1-1.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/1/1.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/2/2-2.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/2/2.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/3/3-3.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/3/3.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/4/4-4.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/4/4.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/5/5-5.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/5/5.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/6/6-6.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/6/6.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/7/7-7.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/7/7.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/8/8-8.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/8/8.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              <div class="col-sm-4 port-col-6-st">
                                 <div class="port-img-small box18 isotope_item hover-scale">
                                    <div class="item-image">
                                       <a href="images/portfolio/website/webportal/9/9-9.jpg" class="fancybox" rel="ligthbox" tabindex="0">
                                          <img loading="lazy" src="images/portfolio/website/webportal/9/9.png">
                                          <div class="box-content"> <i class="fa fa-eye" aria-hidden="true"></i> </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            
         </div>
      </div>
   </div>
</section>
<!--  -->
<section class="service-block pad-tb bg-gradient7">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="common-heading ptag">
					<!-- <span>WE DELIVER OUR BEST</span> -->
					<span>What makes us superior</span>
					<!-- <h2>Reason to Choose Us</h2> -->
					<h2>Choose The Industry Veterans</h2>
					<!-- <p class="mb30">We are obliged to provide an incredible experience by giving high-quality eCommerce website design and development services. What makes us trustworthy partners? Here are the reasons! </p> -->
					<p class="mb30">Websodesign Web Solution is hailed for its inclusive & devoted style for web portal development. We assist enterprises, corporations, individuals, campaigns varying in professions & background by delivering the finest web portal.</p>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-lg-4 col-sm-6 mt30  wow fadeIn" data-wow-delay=".2s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-1.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>Goal Oriented Approach</h4> -->
						<h4>User-Centric Development</h4>
						<!-- <p>Professional eCommerce web development and design team are goal-oriented to ensure customers that we are their best choice. </p> -->
						<p>Our custom web portal developers understand the dynamics of web portals, generating web portals focused on user needs.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".5s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-2.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>Competitive analysis </h4> -->
						<h4>Adaptable User-Consent Setup</h4>
						<p>Adaptable User-Consent Setup consenting specific users access in specific elements of the portal or data stored in the portal.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay=".8s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-3.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>Product customization </h4> -->
						<h4>Wholesome Third-Party Integration</h4>
						<!-- <p>Websodesign Web Solution offer affordable custom eCommerce website design services. </p> -->
						<p>Websodesign Web Solution establishes web portals with functionality advanced with third-party tools for high-quality performance.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.1s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-4.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>SEO</h4> -->
						<h4>Notification Automations</h4>
						<!-- <p>We optimize websites for the highest conversion rates.</p> -->
						<p>Our web portals come with functionality to form notification automation to safeguard vital information & notifications.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.4s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-5.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>Branding strategy-based Content </h4> -->
						<h4>Enhanced Search Efficiency</h4>
						<!-- <p>We create user-friendly and brand-centric content for maximum engagement.</p> -->
						<p>Websodesign Web Solution corroborates advanced search functionality enabling better usability & ease of use for web visitors.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-sm-6 mt30 wow fadeIn" data-wow-delay="1.7s">
				<div class="s-block wide-sblock">
					<div class="s-card-icon"><img src="images/icons/choose-6.png" alt="service" class="img-fluid"></div>
					<div class="s-block-content">
						<!-- <h4>Advanced Features </h4> -->
						<h4>Multi-Device Responsiveness </h4>
						<!-- <p>We build and design websites with unique features at reasonable prices. </p> -->
						<p>Our developers make web portals that are aim to be entirely responsive across all types of devices.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="-cta-btn mt70"> 
			<div class="free-cta-title v-center wow zoomInDown" data-wow-delay="1.8s">
				<!-- <p>Let's Start a <span>New Project</span> Together</p> -->
				<p>Embark <span>On a Successful</span> Journey</p>
				<!-- <a href="#" class="btn-main bg-btn2 lnk">Inquire Now<i class="fas fa-chevron-right fa-icon"></i><span class="circle"></span></a> -->
				<a href="javascript:;" class="btn-main bg-btn lnk wow fadeIn popup_open" onclick="order_now_value(this)" name="for $299" data-wow-delay="0.8s">Let's Begin <i class="fas fa-chevron-right fa-ani"></i><span class="circle"></span></a>
				<a href="javascript:;" class="btn-main bg-btn2 lnk  wow fadeIn" onclick="setButtonURL();"  data-wow-delay="0.8s">Live Chat<i class="fas fa-chevron-right fa-icon fa-ani"></i><span class="circle"></span></a>
			</div>
		</div>
	</div>
</section>
<section class="reviews-block pad-tb">

   <div class="container">

      <div class="row justify-content-center">

         <div class="col-lg-8">

            <div class="common-heading ptag">

               <span>WHAT OUR CLIENTS SAY ABOUT OUR SERVICES</span>

               <h2>Over 1000+ Happy Clients and Growing</h2>

            </div>

         </div>

      </div>

      <div class="row">

         <div class="col-md-4 mt30">

            <div class="reviews-card pr-shadow">

               <div class="row v-center">

                  <div class="col"> <span class="revbx-lr"><i class="fas fa-quote-left"></i></span> </div>

                  <div class="col"> <span class="revbx-rl"><img src="images/client/upwork-logo.png" alt="review service logo"></span> </div>

               </div>

               <div class="review-text">

                  <p>Websodesign Web Solution is a one-stop solution for everything an organization requires. Their skilled developers combined quality with timeliness and created an outstanding website for us. Truly amazed with their work. </p>

               </div>

               <div class="-client-details-">

                  <div class="-reviewr">

                     <img src="images/client/testi-1.jpg" alt="Good Review" class="img-fluid">

                  </div>

                  <div class="reviewer-text">

                     <h4>Steve Martin</h4>

                     <div class="star-rate">

                        <ul>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                        </ul>

                     </div>

                  </div>

               </div>

            </div>

         </div>

         <div class="col-md-4 mt30">

            <div class="reviews-card pr-shadow">

               <div class="row v-center">

                  <div class="col"> <span class="revbx-lr"><i class="fas fa-quote-left"></i></span> </div>

                  <div class="col"> <span class="revbx-rl"><img src="images/client/envato.png" alt="review service logo"></span> </div>

               </div>

               <div class="review-text">

                  <p>Websodesign Web Solution have been a strength for our corporation from the beginning. They have delivered high-value work every single time. I cannot recommend them highly enough. Best company to work with! </p>

               </div>

               <div class="-client-details-">

                  <div class="-reviewr">

                     <img src="images/client/testi-2.jpg" alt="Good Review" class="img-fluid">

                  </div>

                  <div class="reviewer-text">

                     <h4>James Dunkin</h4>

                     <div class="star-rate">

                        <ul>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                        </ul>

                     </div>

                  </div>

               </div>

            </div>

         </div>

         <div class="col-md-4 mt30">

            <div class="reviews-card pr-shadow">

               <div class="row v-center">

                  <div class="col"> <span class="revbx-lr"><i class="fas fa-quote-left"></i></span> </div>

                  <div class="col"> <span class="revbx-rl"><img src="images/client/freelancer-logo.png" alt="review service logo"></span> </div>

               </div>

               <div class="review-text">

                  <p>I am truly amazed with the abilities of Websodesign Web Solution. Their services are unparalleled because of their expertise, rational charges, rapid delivery times, and improved support. Highly recommended for website design. </p>

               </div>

               <div class="-client-details-">

                  <div class="-reviewr">

                     <img src="images/client/testi-3.jpg" alt="Good Review" class="img-fluid">

                  </div>

                  <div class="reviewer-text">

                     <h4>Leah Tyler </h4>

                     <div class="star-rate">

                        <ul>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)" class="chked"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                           <li> <a href="javascript:void(0)"><i class="fas fa-star" aria-hidden="true"></i></a> </li>

                        </ul>

                     </div>

                  </div>

               </div>

            </div>

         </div>

      </div>

   </div>

</section><!--  -->
<section class="service-block pad-tb light-dark">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="common-heading ptag">
					<!-- <span>OUR PROCESS</span> -->
					<span>We follow</span>
					<!-- <h2>How We Create Outstanding Websites</h2> -->
					<h2>Efficient Approach to Make Web Portals</h2>
					<p>We consist of a highly diverse team of web professionals, technology geeks & business minds developing web portals & ensuring a delightful experience for visitors.</p>
				</div>
			</div>
		</div>
		<div class="row upset justify-content-center mt60">
			<div class="col-lg-4 v-center order1">
				<div class="image-block1">
					<img src="images/process/process-1.jpg" alt="Process" class="img-fluid" />
				</div>
			</div>
			<div class="col-lg-7 v-center order2">
				<div class="ps-block">
					<span>1</span>
					<!-- <h3>Effective Strategy Establishment </h3> -->
					<h3>We Initiate Planning Visualizing Business Needs</h3>
					<!-- <p>Professional eCommerce web development team doesn’t start the process without making a strong and result-driven development strategy. Integrate them with eCommerce website design services to boost business ROI.  </p> -->
					<p>Websodesign Web Solution begins constructing a web portal of clients bearing in mind the specific business necessities. We work on the project considering business objectives, & future prospects.</p>
				</div>
			</div>
		</div>
		<div class="row upset justify-content-center mt60">
			<div class="col-lg-7 v-center order2">
				<div class="ps-block">
					<span>2</span>
					<!-- <h3>Work on an eCommerce website design with proper planning </h3> -->
					<h3>Integrating Iterative Approach in Portal Development</h3>
					<!-- <p>Our professional UX/UI designers prepare cutting-edge and aesthetic web layouts. Websodesign Web Solution allows you to choose a suitable web pattern as per your business requirements. </p> -->
					<p>Websodesign Web Solution erects a web portal based upon a robust design embodying key features including Intuitive back end, front end & APIs ideal for use of a multitude of web users.</p>
				</div>
			</div>
			<div class="col-lg-4 v-center order1">
				<div class="image-block1">
					<img src="images/process/process-2.jpg" alt="Process" class="img-fluid" />
				</div>
			</div>
		</div>
		<div class="row upset justify-content-center mt60">
			<div class="col-lg-4 v-center order1">
				<div class="image-block1">
					<img src="images/process/process-3.jpg" alt="Process" class="img-fluid" />
				</div>
			</div>
			<div class="col-lg-7 v-center order2">
				<div class="ps-block">
					<span>3</span>
					<!-- <h3>Smooth Development and Coding </h3> -->
					<h3>Well-Executed Quality Assurance Checks of Web Portal</h3>
					<!-- <p>Our qualified developers use interactive UI with effective eCommerce web solutions to fulfill your project needs. </p> -->
					<p>For first-rate results, Websodesign Web Solution implements well-executed quality assurance checks of the web portal several times in order to make sure it meets the modern-day user demands.</p>
				</div>
			</div>
		</div>
		<div class="row upset justify-content-center mt60">
			<div class="col-lg-7 v-center order2">
				<div class="ps-block">
					<span>4</span>
					<!-- <h3>Publication and Launching </h3> -->
					<h3>Finishing Task with Launch & Publication of Web Portal</h3>
					<!-- <p>We don’t launch a product without implementing a quality assurance (QA) process. We aim to deliver your website with absolute perfection.</p> -->
					<p>Websodesign Web Solution ends the project post QA of web portal development in the launch & publication stage, converting ideas into purposeful, handy & consumer-friendly web portals.</p>
				</div>
			</div>
			<div class="col-lg-4 v-center order1">
				<div class="image-block1">
					<img src="images/process/process-4.jpg" alt="Process" class="img-fluid" />
				</div>
			</div>
		</div>
	</div>
</section>
<section class="cta-area pad-tb">
						<div class="container">
							<div class="row justify-content-center">
								<div class="col-lg-8">
									<div class="common-heading">
										<span>Turn to Specialists</span>
										<!-- <h2>We’d Love to Listen to Your Website Requirements </h2> -->
										<h2>Consult Experts to Get <br>Fully-Functional Web Portals</h2>
										<a href="javascript:;" class="btn-main bg-btn lnk wow fadeIn popup_open" onclick="order_now_value(this)" name="for $244" data-wow-delay="0.8s">Get Started <i class="fas fa-chevron-right fa-ani"></i><span class="circle"></span></a>
								<a href="javascript:;" class="btn-main bg-btn2 lnk  wow fadeIn" onclick="setButtonURL();"  data-wow-delay="0.8s">Live Chat<i class="fas fa-chevron-right fa-icon fa-ani"></i><span class="circle"></span></a>
										<p class="cta-call">Or call us now <a href="tel:<?php echo $contactphonenumber ?>"><i class="fas fa-phone-alt"></i> <?php echo $contactphonenumber ?></a></p>
									</div>
								</div>
							</div>
						</div>
						<div class="shape shape-a1"><img src="images/shape/shape-3.svg" alt="shape"></div>
						<div class="shape shape-a2"><img src="images/shape/shape-4.svg" alt="shape"></div>
						<div class="shape shape-a3"><img src="images/shape/shape-13.svg" alt="shape"></div>
						<div class="shape shape-a4"><img src="images/shape/shape-11.svg" alt="shape"></div>
					</section>
               <?php 
include 'footer.php';
?>